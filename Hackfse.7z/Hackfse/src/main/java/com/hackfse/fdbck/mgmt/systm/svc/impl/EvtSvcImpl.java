package com.hackfse.fdbck.mgmt.systm.svc.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hackfse.fdbck.mgmt.systm.dao.OutReachEventInfoDao;
import com.hackfse.fdbck.mgmt.systm.dao.OutReachEventSummaryDao;
import com.hackfse.fdbck.mgmt.systm.dao.OutReachNotRegisteredDao;
import com.hackfse.fdbck.mgmt.systm.dao.OutReachRegisteredDao;
import com.hackfse.fdbck.mgmt.systm.model.OutReachEventInfoDTO;
import com.hackfse.fdbck.mgmt.systm.model.OutReachEventSummeryDTO;
import com.hackfse.fdbck.mgmt.systm.model.OutReachNotRegisteredDTO;
import com.hackfse.fdbck.mgmt.systm.model.OutReachRegisteredDTO;
import com.hackfse.fdbck.mgmt.systm.res.vo.OutReachEventInfoRspVo;
import com.hackfse.fdbck.mgmt.systm.res.vo.OutReachEventSummeryRspVo;
import com.hackfse.fdbck.mgmt.systm.res.vo.OutReachNotRegisteredRspVo;
import com.hackfse.fdbck.mgmt.systm.res.vo.OutReachRegisteredRspVo;

@Service
public class EvtSvcImpl {
	
	@Autowired
	private OutReachRegisteredDao outReachRegisteredDao;
	
	@Autowired
	private OutReachNotRegisteredDao outReachNotRegisteredDao;
	
	@Autowired
	private OutReachEventInfoDao outReachEventInfoDao;
	
	@Autowired
	private OutReachEventSummaryDao outReachEventSummaryDao;

	public OutReachEventSummeryRspVo findEvntSummry(final String eventId) {
		final Optional<OutReachEventSummeryDTO> outReachEventSummeryDTO = outReachEventSummaryDao.findById(eventId);
		final OutReachEventSummeryRspVo eventSummeryRspVo = new OutReachEventSummeryRspVo();
		if(outReachEventSummeryDTO.isPresent())
			BeanUtils.copyProperties(outReachEventSummeryDTO.get(), eventSummeryRspVo);
		return eventSummeryRspVo;
	}
	
	public List<OutReachEventSummeryRspVo> findAllEvtSummry() {
		final List<OutReachEventSummeryDTO> eventSummeryDTOs = outReachEventSummaryDao.findAll();
		final List<OutReachEventSummeryRspVo> eventSummeryRspVos = new ArrayList<>();
		eventSummeryDTOs.stream().forEach(evnt -> {
			final OutReachEventSummeryRspVo eventInfoRspVo = new OutReachEventSummeryRspVo();
			BeanUtils.copyProperties(evnt, eventInfoRspVo);
			eventSummeryRspVos.add(eventInfoRspVo);
		});
		return eventSummeryRspVos;
	}

	public List<OutReachEventInfoRspVo> findAllEmpInAnEvt() {
		final List<OutReachEventInfoDTO> eventInfoDTO = outReachEventInfoDao.findAll();
		final List<OutReachEventInfoRspVo> eventInfoRspVos = new ArrayList<>();
		eventInfoDTO.stream().forEach(evnt -> {
			final OutReachEventInfoRspVo eventInfoRspVo = new OutReachEventInfoRspVo();
			BeanUtils.copyProperties(evnt, eventInfoRspVo);
			eventInfoRspVos.add(eventInfoRspVo);
		});
		return eventInfoRspVos;
	}
	
	public List<OutReachNotRegisteredRspVo> findAllUnrgstrd() {
		final List<OutReachNotRegisteredDTO> eventInfoDTO = outReachNotRegisteredDao.findAll();
		final List<OutReachNotRegisteredRspVo> eventInfoRspVos = new ArrayList<>();;
		eventInfoDTO.stream().forEach(evnt -> {
			final OutReachNotRegisteredRspVo eventInfoRspVo = new OutReachNotRegisteredRspVo();
			BeanUtils.copyProperties(evnt, eventInfoRspVo);
			eventInfoRspVos.add(eventInfoRspVo);
		});
		return eventInfoRspVos;
	}
	
	public List<OutReachRegisteredRspVo> findAllUnattnd() {
		final List<OutReachRegisteredDTO> eventInfoDTO = outReachRegisteredDao.findAll();
		final List<OutReachRegisteredRspVo> eventInfoRspVos = new ArrayList<>();
		eventInfoDTO.stream().forEach(evnt -> {
			final OutReachRegisteredRspVo eventInfoRspVo = new OutReachRegisteredRspVo();
			BeanUtils.copyProperties(evnt, eventInfoRspVo);
			eventInfoRspVos.add(eventInfoRspVo);
		});
		return eventInfoRspVos;
	}
}