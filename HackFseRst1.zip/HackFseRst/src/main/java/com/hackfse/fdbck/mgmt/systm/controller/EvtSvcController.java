package com.hackfse.fdbck.mgmt.systm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hackfse.fdbck.mgmt.systm.cnst.AppConstants;
import com.hackfse.fdbck.mgmt.systm.res.vo.ErrorResponse;
import com.hackfse.fdbck.mgmt.systm.res.vo.OutReachEventInfoRspVo;
import com.hackfse.fdbck.mgmt.systm.res.vo.OutReachEventSummeryRspVo;
import com.hackfse.fdbck.mgmt.systm.res.vo.OutReachNotRegisteredRspVo;
import com.hackfse.fdbck.mgmt.systm.res.vo.OutReachRegisteredRspVo;
import com.hackfse.fdbck.mgmt.systm.svc.impl.EvtSvcImpl;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class EvtSvcController {
	
	@Autowired
	private EvtSvcImpl evtSvcImpl;
	
	@ApiOperation(nickname = "findEvtSummry", value = "This API is retrieve Event Summary details against an event ID", response = OutReachEventSummeryRspVo.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "OK", response = OutReachEventSummeryRspVo.class),
			@ApiResponse(code = 400, message = "Bad Request", response = ErrorResponse.class),
			@ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
			@ApiResponse(code = 500, message = "Internal Server Error (Server Error)", response = ErrorResponse.class),
			@ApiResponse(code = 503, message = "Service Unavailable", response = ErrorResponse.class) })

	@GetMapping(value = "/findEvtSummry", produces = { "application/json;charset=UTF-8" })
	@Secured({AppConstants.ROLE_ADMIN})
	public ResponseEntity<OutReachEventSummeryRspVo> findEvtSummry(@RequestParam("eventId") String eventId) throws Exception {
		final OutReachEventSummeryRspVo evntSummryVo = evtSvcImpl.findEvntSummry(eventId);
		return ResponseEntity.ok().body(evntSummryVo);
	}
	
	@ApiOperation(nickname = "findAllEvtSummry", value = "This API is retrieve all Event Summary details", response = OutReachEventSummeryRspVo.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "OK", response = OutReachEventSummeryRspVo.class),
			@ApiResponse(code = 400, message = "Bad Request", response = ErrorResponse.class),
			@ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
			@ApiResponse(code = 500, message = "Internal Server Error (Server Error)", response = ErrorResponse.class),
			@ApiResponse(code = 503, message = "Service Unavailable", response = ErrorResponse.class) })

	@GetMapping(value = "/findAllEvtSummry", produces = { "application/json;charset=UTF-8" })
	@Secured({AppConstants.ROLE_ADMIN})
	public ResponseEntity<List<OutReachEventSummeryRspVo>> findAllEvtSummry() throws Exception {
		final List<OutReachEventSummeryRspVo> evntSummryVoLst = evtSvcImpl.findAllEvtSummry();
		return ResponseEntity.ok().body(evntSummryVoLst);
	}
	
	@ApiOperation(nickname = "findAllEmpAttndAnEvt", value = "This API retrives records of volunteers attended an event", response = OutReachEventInfoRspVo.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "OK", response = OutReachEventInfoRspVo.class),
			@ApiResponse(code = 400, message = "Bad Request", response = ErrorResponse.class),
			@ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
			@ApiResponse(code = 500, message = "Internal Server Error (Server Error)", response = ErrorResponse.class),
			@ApiResponse(code = 503, message = "Service Unavailable", response = ErrorResponse.class) })

	@GetMapping(value = "/findAllEmpAttndAnEvt", produces = { "application/json;charset=UTF-8" })
	@Secured({AppConstants.ROLE_ADMIN})
	public ResponseEntity<List<OutReachEventInfoRspVo>> findAllEmpAttndAnEvt() throws Exception {
		final List<OutReachEventInfoRspVo> evntInfoRsp = evtSvcImpl.findAllEmpInAnEvt();
		return ResponseEntity.ok().body(evntInfoRsp);
	}
	
	@ApiOperation(nickname = "findAllVolUnrgstrdEvt", value = "This API retrives records of volunteers degistered from event", response = OutReachNotRegisteredRspVo.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "OK", response = OutReachNotRegisteredRspVo.class),
			@ApiResponse(code = 400, message = "Bad Request", response = ErrorResponse.class),
			@ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
			@ApiResponse(code = 500, message = "Internal Server Error (Server Error)", response = ErrorResponse.class),
			@ApiResponse(code = 503, message = "Service Unavailable", response = ErrorResponse.class) })

	@GetMapping(value = "/findAllVolUnrgstrdEvt", produces = { "application/json;charset=UTF-8" })
	@Secured({AppConstants.ROLE_ADMIN})
	public ResponseEntity<List<OutReachNotRegisteredRspVo>> findAllVolUnrgstrdEvt() throws Exception {
		final List<OutReachNotRegisteredRspVo> evntInfoRsp = evtSvcImpl.findAllUnrgstrd();
		return ResponseEntity.ok().body(evntInfoRsp);
	}
	
	@ApiOperation(nickname = "findAllVolUnattndedEvt", value = "This API retrives records of volunteers degistered from event", response = OutReachRegisteredRspVo.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "OK", response = OutReachRegisteredRspVo.class),
			@ApiResponse(code = 400, message = "Bad Request", response = ErrorResponse.class),
			@ApiResponse(code = 404, message = "Not Found", response = ErrorResponse.class),
			@ApiResponse(code = 500, message = "Internal Server Error (Server Error)", response = ErrorResponse.class),
			@ApiResponse(code = 503, message = "Service Unavailable", response = ErrorResponse.class) })

	@GetMapping(value = "/findAllVolUnattndedEvt", produces = { "application/json;charset=UTF-8" })
	@Secured({AppConstants.ROLE_ADMIN})
	public ResponseEntity<List<OutReachRegisteredRspVo>> findAllVolUnattndedEvt() throws Exception {
		final List<OutReachRegisteredRspVo> evntInfoRsp = evtSvcImpl.findAllUnattnd();
		return ResponseEntity.ok().body(evntInfoRsp);
	}
}
