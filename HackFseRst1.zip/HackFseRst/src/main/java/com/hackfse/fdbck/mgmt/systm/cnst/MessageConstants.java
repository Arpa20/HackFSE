package com.hackfse.fdbck.mgmt.systm.cnst;

public class MessageConstants {
	
	public static final String INVALID_TOKEN = "Invalid Token";
	public static final String VALID_TOKEN = "Valid token for user ";
	public static final String USERNAME_OR_PWD_INVALID = "Username or Password should not be empty";

}
