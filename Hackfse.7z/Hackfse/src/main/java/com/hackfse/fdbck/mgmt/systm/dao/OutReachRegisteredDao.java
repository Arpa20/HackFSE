package com.hackfse.fdbck.mgmt.systm.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hackfse.fdbck.mgmt.systm.model.OutReachRegisteredDTO;

public interface OutReachRegisteredDao extends JpaRepository<OutReachRegisteredDTO, String> {

}
