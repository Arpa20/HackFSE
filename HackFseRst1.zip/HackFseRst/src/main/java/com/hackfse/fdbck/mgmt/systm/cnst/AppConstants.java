package com.hackfse.fdbck.mgmt.systm.cnst;

public class AppConstants {
	
	private AppConstants() {}
	
    public static final String DEFAULT_PAGE_NUMBER = "0";
    public static final String DEFAULT_PAGE_SIZE = "30";
    public static final int MAX_PAGE_SIZE = 50;
    public static final String AUTH_HDR = "Authorization";
    public static final String BEARER_ENTRY = "Bearer";
    public static final String ROLE_ADMIN = "ROLE_ADMINS";
    public static final String ROLE_POC = "ROLE_POCS";
    public static final String COMMA_SEPRTR = ",";
    public static final String AUTHORITIES_KEY = "AUTHORITIES_KEY";
    public static final String LDAP_USER_PRINCIPAL = "PRINCIPAL";
}